const main= document.querySelector(".main")
const menu = document.querySelector('.menu')
const middle = document.querySelector('.middle')
const week_temp = document.querySelector('.week_temp')
const start = document.querySelector(".start")
 let box = document.getElementById('test');
let d = document.getElementById('t')
let bo = document.getElementById('boxs')
let bt = document.querySelector(".btn")
let start_btn = document.getElementById('s')
let city = "Bihar Sharif";

const API_KEY = 'd38e37d49cfa48b580c143653230305';
const url = `https://api.weatherapi.com/v1/forecast.json?key=${API_KEY}&q=${city}&days=7&aqi=yes&alerts=yes
 `;

const week_box = document.querySelector(".t")



function see_more() {

 for (var i = 0; i <= 20; i++) {
  
 let c = document.createElement('div')
  c.innerHTML = `       
  <div class="condition_data">
                    <span id="heading">Uv Index</span>
                    <br>
                    <span id="value">6</span>
                  </div>`;
  box.appendChild(c)

 }

if (bt.innerText == 'see more') {

let hour = document.createElement('div');

hour.innerHTML = ` 
<div id="t" class="today">
     <span id="heading">Today's Forecast</span>
     <div class="for_box">
      <div class="for_data">
       <span id="heading">08:00</span>
       <img src="assets/cloud.png" alt="assets/cloud.png" width="80px" height="80px">
       <span id="temp_min">28°c</span>
      </div>
      <div class="for_data">
       <span id="heading">08:00</span>
       <img src="assets/cloud.png" alt="assets/cloud.png" width="80px" height="80px">
       <span id="temp_min">28°c</span>
      </div>
     </div>



    </div>`;
    week_box.appendChild(hour)

  bo.style.height = "100%";
  bo.style.backgroundColor = "#fff";
  d.style.display = "none";
  bt.innerText = "see less"
 }
 else if (bt.innerText == 'see less') {  
  bo.style.height = "280px";
  week_box.style.display= "none"
  bo.style.backgroundColor = "var(--back-grey)"
  d.style.display = "block";
  bt.innerText = "see more";
  
 }
}


function get(){
 fetch(url).then((response)=>{
  return response.json();
 }).then((data)=>{
  console.log(data)
  
  let current_weather= {...data.current};
  let current_condition = {...current_weather.condition}
  console.log(current_weather)
  console.log(current_condition)
  
  let current_air_quality = {...current_weather.air_quality}
  console.log(current_air_quality)
  
 }).catch((e)=>{
  console.log(e)
 })
}
get();

window.onload = function (){
 menu.classList.add('hide')
  middle.classList.add('hide')
   week_temp.classList.add('hide')
   
  
}

start_btn.addEventListener('click',()=>{
 start.classList.add('hide')
menu.classList.remove('hide')
middle.classList.remove('hide')
week_temp.classList.remove('hide')
})



